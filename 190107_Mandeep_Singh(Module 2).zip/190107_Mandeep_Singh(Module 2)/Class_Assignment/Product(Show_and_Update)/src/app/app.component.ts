
import { Component } from '@angular/core';
import Comm from '../app/jsonfolder/Comm.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 prod=Comm;
 isValid=false;
 valid=false;
 showProduct(i)
 {
   this.isValid=true;
 }
deleteProduct(i)
{
  console.log("before adding",this.prod)
  this.prod.splice(i,1)
  console.log("after adding",this.prod)
}
searchProduct(i){
  this.valid=true;
}
searchByName(event){
  this.isValid=true;
  this.valid=true;
this.prod= this.prod.filter(singleItem =>
singleItem.name.toLowerCase().includes(event.target.value.toLowerCase()))
}
searchByCategory(event){
  this.isValid=true;
  this.valid=true;
  this.prod= this.prod.filter(singleItem =>
    singleItem.category.toLowerCase().includes(event.target.value.toLowerCase()))
}
}
