import { Injectable } from '@angular/core';
import { Employees } from './employees';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  static employeeArray: Employees[] = [];

  constructor() { }

  addEmployeeService(addForm) {

    const employeeObj = new Employees();
    employeeObj.id = addForm.id;
    employeeObj.name = addForm.name;
    employeeObj.email = addForm.email;
    employeeObj.phone = addForm.phone;
    EmployeeService.employeeArray.push(employeeObj);
  }

  listEmployeeService() {
    return EmployeeService.employeeArray;
  }

  deleteEmployeeService(i) {
    EmployeeService.employeeArray.splice(i, 1);
  }
}
