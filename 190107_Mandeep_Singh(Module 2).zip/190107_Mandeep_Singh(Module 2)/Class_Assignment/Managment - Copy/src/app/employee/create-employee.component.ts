import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Employees } from '../employees';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  empServiceObj: EmployeeService = new EmployeeService();
  employeeList: Employees[];

  constructor() {
   }

  ngOnInit() {
 }
 addEmployee(addForm) {
  this.empServiceObj.addEmployeeService(addForm);
  alert('Employee Added.');
  // console.log(this.employeeList);
}

}
