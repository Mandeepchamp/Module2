import { Component, OnInit } from '@angular/core';
import { Employees } from '../employees';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {


  employeeServiceObj: EmployeeService = new EmployeeService();
  empList: Employees[] = [];

  constructor() { }

  ngOnInit() {
    this.empList = this.employeeServiceObj.listEmployeeService();
  }

  deleteEmployee(i) {
    this.employeeServiceObj.deleteEmployeeService(i);
  }
}
